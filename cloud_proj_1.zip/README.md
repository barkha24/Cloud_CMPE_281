# cloudprj1 [![NPM version](https://badge.fury.io/js/cloudprj1.svg)](https://npmjs.org/package/cloudprj1) [![Build Status](https://travis-ci.org/Barkha Choithani/cloudprj1.svg?branch=master)](https://travis-ci.org/Barkha Choithani/cloudprj1)

> Cloud Object Store is my cloud project 1 for my subject CMPE 281

## Installation

```sh
$ npm install --save cloudprj1
```

## Usage

```js
var cloudprj1 = require('cloudprj1');
cloudprj1();
```

## License

ISC © [Barkha Choithani](www.cloudobjectstore.co.uk)
