var prjBucketName = 'cloudproj1s3bucket';
var prjbucketRegion = 'us-east-1'
var prjIdentityPoolId = 'PUT YOUR IDENTITY POOL ID';

AWS.config.update({
  region: prjbucketRegion,
  credentials: new AWS.CognitoIdentityCredentials({
    IdentityPoolId: prjIdentityPoolId
  })
});

AWS.config.credentials.get(function(){

   
    var accessKeyId = AWS.config.credentials.accessKeyId;
    var secretAccessKey = AWS.config.credentials.secretAccessKey;
    var sessionToken = AWS.config.credentials.sessionToken;

});

var prjS3 = new AWS.S3({
  apiVersion: '2006-03-01',
  params: {Bucket: prjBucketName}
});

function listFolders() {
  prjS3.listObjects({Delimiter: '/'}, function(err, data) {
    if (err) {
      return alert('There was an error listing your folders: ' + err.message);
    } else {
      var folders = data.CommonPrefixes.map(function(commonPrefix) {
        var prefix = commonPrefix.Prefix;
        var folderName = decodeURIComponent(prefix.replace('/', ''));
        return getHtml([
	        '<table border="1">',
	
	'<tbody>',
		'<tr>',
		'<td>','<em onclick="viewFolder(\'' + folderName + '\')">',
              folderName,
            '</em>','</td>',
			'<td>','<em onclick="deleteFolder(\'' + folderName + '\')">Delete</em>',
'</td>',
		'</tr>',
	'</tbody>',
'</table>'

	       
          
        ]);
      });
      var message = folders.length ?
        getHtml([
          '<p>Click on folder name to view its files</p>',
          
        ]) :
        '<p>You do not have any folder. Please Create folder.</p>';
      var htmlTemplate = [
        '<h2>Folder</h2>',
        message,
        '<ul>',
          getHtml(folders),
        '</ul>'
        
            ]
      document.getElementById('app').innerHTML = getHtml(htmlTemplate);
    }
  });
}

function viewFolder(folderName) {
  var folderFilesKey = encodeURIComponent(folderName) + '//';
 

  prjS3.listObjects({Prefix: folderFilesKey}, function(err, data) {
    if (err) {
      return alert('There was an error viewing your folder: ' + err.message);
    }
    // `this` references the AWS.Response instance that represents the response
    var href = this.request.httpRequest.endpoint.href;
    var bucketUrl = href + prjBucketName + '/';

    var files = data.Contents.map(function(file) {
      var fileKey = file.Key;
      var fileUrl = bucketUrl + encodeURIComponent(fileKey);
      return getHtml([
	      
	      '<div>',
	      '<em>',
              fileKey.replace(folderFilesKey, ''),
            '</em>','<em>','&nbsp;',
          
          '<button>',
          '<a color = "white" href="'+fileUrl+'"><font color="black">Download</font></a>','&nbsp;','</button>',
            
          '</em>','<button>','<em onclick="deleteFile(\'' + folderName + "','" + fileKey + '\')">','<u>','Delete ','</u>',
            '</em>','</button>',
                     '</div>'
        
      ]);
      getObjDetail(fileKey);
    });
    
    var message = files.length ?
      '<p>Files</p>' :
      '<p>You do not have any files in this folder. Please add files.</p>';
    var htmlTemplate = [
      '<h2>',
        'Folder: ' + folderName,
      '</h2>',
      message,
      '<div>',
        getHtml(files),
      '</div>',
      '<input id="fileupload" type="file" accept="file_extension">',
      '<button id="upload" onclick="addFile(\'' + folderName +'\')">',
        'Upload/Update',
      '</button>',
      '<button onclick="listFolders()">',
        'Back To Folders',
      '</button>',
    ]
    document.getElementById('app').innerHTML = getHtml(htmlTemplate);
  });
}

function createFolder(folderName) {
  folderName = folderName.trim();
  if (!folderName) {
    return alert('Folder names must contain at least one non-space character.');
  }
  if (folderName.indexOf('/') !== -1) {
    return alert('Folder names cannot contain slashes.');
  }
  var folderKey = encodeURIComponent(folderName) + '/';
  prjS3.headObject({Key: folderKey}, function(err, data) {
    if (!err) {
      return alert('Folder already exists.');
    }
    if (err.code !== 'NotFound') {
      return alert('There was an error creating your folder: ' + err.message);
    }
    prjS3.putObject({Key: folderKey}, function(err, data) {
      if (err) {
        return alert('There was an error creating your folder: ' + err.message);
      }
      alert('Successfully created folder.');
      viewFolder(folderName);
    });
  });
}
function addFile(folderName) {
  var files = document.getElementById('fileupload').files;
  if (!files.length) {
    return alert('Please choose a file to upload first.');
  }
  var file = files[0];
  var fileName = file.name;
  var folderFilesKey = encodeURIComponent(folderName) + '//';

  var fileKey = folderFilesKey + fileName;
  prjS3.upload({
    Key: fileKey,
    Body: file,
    ACL: 'public-read'
  }, function(err, data) {
    if (err) {
      return alert('There was an error uploading your file: ', err.message);
    }
    alert('Successfully uploaded file.');
    viewFolder(folderName);
    
  });
}

function deleteFile(folderName, fileKey) {
  prjS3.deleteObject({Key: fileKey}, function(err, data) {
    if (err) {
      return alert('There was an error deleting your file: ', err.message);
    }
    alert('Successfully deleted file.');
    viewFolder(folderName);
  });
}

function getObjDetail(fileKey) {
var params = {
  Bucket: "prjS3", 
  Key: fileKey, 
  
 };
 prjS3.getObject(params, function(err, data) {
   if (err) console.log(err, err.stack); // an error occurred
   else     console.log(data);           // successful response
   /*
   data = {
    AcceptRanges: "bytes", 
    ContentLength: 10, 
    ContentRange: "bytes 0-9/43", 
    ContentType: "text/plain", 
    ETag: "\"0d94420ffd0bc68cd3d152506b97a9cc\"", 
    LastModified: <Date Representation>, 
    Metadata: {
    }, 
    VersionId: "null"
   }*/
   
    });
 }


