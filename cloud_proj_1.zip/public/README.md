
* University Name: http://www.sjsu.edu/ 

* Course: Cloud Technologies

* Professor: Sanjay Garje 

* ISA: Divyankitha Urs

* Student: Barkha Choithani https://www.linkedin.com/in/barkhachoithani

* Project Introduction (

Cloud Object Store is my first project in this course.
This web application allows users to upload, download, delete and maintain versions of objects (files) on cloud.
AWS SDK for various services are leveraged in this development.
I have used Amazon S3 for storing objects in this web application.
Replication and archival is maintained for objects.
Front-end and logic is implemented in HTML-CSS, JavaScript and Node.js
Code is deployed using Elastic Beanstalk and EC2.
The website is hosted using Route 53.

* Sample Demo Screenshots
Login Screen










List of Folders on Cloud Store



Uploading File



Downloading File



Deleting the file





Pre-requisites Set Up :

List of AWS resources:

* Amazon S3
* Elastic Beanstalk
* CloudWatch
* Route 53
* Amazon SNS
* Elastic Load Balancer
* Amazon RDS
* Cloud Front Distribution
* Amazon Glacier


# cloudprj1 [![NPM version](https://badge.fury.io/js/cloudprj1.svg)](https://npmjs.org/package/cloudprj1) [![Build Status](https://travis-ci.org/Barkha Choithani/cloudprj1.svg?branch=master)](https://travis-ci.org/Barkha Choithani/cloudprj1)

> Cloud Object Store is my first cloud project in Masters subject CMPE 281

## Installation

```sh
$ npm install --save cloudprj1
```

## Run and Usage

```js
var cloudprj1 = require('cloudprj1');
cloudprj1();
```

## License

ISC  [Barkha Choithani](www.cloudobjectstore.co.uk)

