var prjBucketName = 'cloudproj1s3bucket';
var prjbucketRegion = 'us-east-1'
var prjIdentityPoolId = 'PUT YOUR IDENTITY POOL ID';

AWS.config.update({
  region: prjbucketRegion,
  credentials: new AWS.CognitoIdentityCredentials({
    IdentityPoolId: prjIdentityPoolId
  })
});

AWS.config.credentials.get(function(){

    // Credentials will be available when this function is called.
    var accessKeyId = AWS.config.credentials.accessKeyId;
    var secretAccessKey = AWS.config.credentials.secretAccessKey;
    var sessionToken = AWS.config.credentials.sessionToken;

});

var prjS3 = new AWS.S3({
  apiVersion: '2006-03-01',
  params: {Bucket: prjBucketName}
});

function listFolders() {
  prjS3.listObjects({Delimiter: '/'}, function(err, data) {
    if (err) {
      return alert('There was an error listing your folders: ' + err.message);
    } else {
      var albums = data.CommonPrefixes.map(function(commonPrefix) {
        var prefix = commonPrefix.Prefix;
        var albumName = decodeURIComponent(prefix.replace('/', ''));
        return getHtml([
	        '<table border="1">',
	
	'<tbody>',
		'<tr>',
		'<td>','<span onclick="viewFolder(\'' + albumName + '\')">',
              albumName,
            '</span>','</td>',
			'<td>','<button onclick="deleteFile(\'' + albumName + '\')">Delete</button>',
'</td>',
		'</tr>',
	'</tbody>',
'</table>'

	       
          
        ]);
      });
      var message = albums.length ?
        getHtml([
          '<p>Click on folder name to view its files</p>',
          //'<p>Click on Delete  to delete the folder.</p>'
        ]) :
        '<p>You do not have any folder. Please Create folder.</p>';
      var htmlTemplate = [
        '<h2>Folder</h2>',
        message,
        '<ul>',
          getHtml(albums),
        '</ul>'
        
            ]
      document.getElementById('app').innerHTML = getHtml(htmlTemplate);
    }
  });
}

function viewFolder(albumName) {
  var albumPhotosKey = encodeURIComponent(albumName) + '//';
 

  prjS3.listObjects({Prefix: albumPhotosKey}, function(err, data) {
    if (err) {
      return alert('There was an error viewing your folder: ' + err.message);
    }
    // `this` references the AWS.Response instance that represents the response
    var href = this.request.httpRequest.endpoint.href;
    var bucketUrl = href + prjBucketName + '/';

    var photos = data.Contents.map(function(photo) {
      var photoKey = photo.Key;
      var photoUrl = bucketUrl + encodeURIComponent(photoKey);
      return getHtml([
	      
	      '<div>',
	      '<em>',
              photoKey.replace(albumPhotosKey, ''),
            '</em>','<em>','&nbsp;',
          
          '<button>',
          '<a color = "white" href="'+photoUrl+'"><font color="black">Download</font></a>','&nbsp;','</button>',
            
          '</em>','<button>','<em onclick="deleteFile(\'' + albumName + "','" + photoKey + '\')">','<u>','Delete ','</u>',
            '</em>','</button>',
                     '</div>'
        
      ]);
      
    });
    
    var message = photos.length ?
      '<p>Files</p>' :
      '<p>You do not have any files in this folder. Please add files.</p>';
    var htmlTemplate = [
      '<h2>',
        'Folder: ' + albumName,
      '</h2>',
      message,
      '<div>',
        getHtml(photos),
      '</div>',
      '<input id="fileupload" type="file" accept="file_extension">',
      '<button id="upload" onclick="addFile(\'' + albumName +'\')">',
        'Upload/Update',
      '</button>',
      '<button onclick="listFolders()">',
        'Back To Folders',
      '</button>',
    ]
    document.getElementById('app').innerHTML = getHtml(htmlTemplate);
  });
}

function createFolder(albumName) {
  albumName = albumName.trim();
  if (!albumName) {
    return alert('Folder names must contain at least one non-space character.');
  }
  if (albumName.indexOf('/') !== -1) {
    return alert('Folder names cannot contain slashes.');
  }
  var albumKey = encodeURIComponent(albumName) + '/';
  prjS3.headObject({Key: albumKey}, function(err, data) {
    if (!err) {
      return alert('Folder already exists.');
    }
    if (err.code !== 'NotFound') {
      return alert('There was an error creating your folder: ' + err.message);
    }
    prjS3.putObject({Key: albumKey}, function(err, data) {
      if (err) {
        return alert('There was an error creating your folder: ' + err.message);
      }
      alert('Successfully created album.');
      viewFolder(albumName);
    });
  });
}
function addFile(albumName) {
  var files = document.getElementById('fileupload').files;
  if (!files.length) {
    return alert('Please choose a file to upload first.');
  }
  var file = files[0];
  var fileName = file.name;
  var albumPhotosKey = encodeURIComponent(albumName) + '//';

  var photoKey = albumPhotosKey + fileName;
  prjS3.upload({
    Key: photoKey,
    Body: file,
    ACL: 'public-read'
  }, function(err, data) {
    if (err) {
      return alert('There was an error uploading your file: ', err.message);
    }
    alert('Successfully uploaded file.');
    viewFolder(albumName);
    
  });
}

function deleteFile(albumName, photoKey) {
  prjS3.deleteObject({Key: photoKey}, function(err, data) {
    if (err) {
      return alert('There was an error deleting your file: ', err.message);
    }
    alert('Successfully deleted file.');
    viewFolder(albumName);
  });
}

function getObjDetail(photoKey) {
var params = {
  Bucket: "prjS3", 
  Key: photoKey, 
  
 };
 prjS3.getObject(params, function(err, data) {
   if (err) console.log(err, err.stack); // an error occurred
   else     console.log(data);           // successful response
   /*
   data = {
    AcceptRanges: "bytes", 
    ContentLength: 10, 
    ContentRange: "bytes 0-9/43", 
    ContentType: "text/plain", 
    ETag: "\"0d94420ffd0bc68cd3d152506b97a9cc\"", 
    LastModified: <Date Representation>, 
    Metadata: {
    }, 
    VersionId: "null"
   }*/
   
    });
 }


